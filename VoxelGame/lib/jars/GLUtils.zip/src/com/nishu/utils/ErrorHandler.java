package com.nishu.utils;

public class ErrorHandler {
	
	public static void printError(String message){
		System.err.println(message);
	}
}
